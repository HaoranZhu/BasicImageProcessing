/*****************************************************************************
 *   ViewController.m
 ******************************************************************************
 *   by Kirill Kornyakov and Alexander Shishkov, 5th May 2013
 ******************************************************************************
 *   Chapter 1 of the "OpenCV for iOS" book
 *
 *   Getting started with iOS, helps you to set up your development environment
 *   and run your first "Hello World" iOS application.
 *
 *   Copyright Packt Publishing 2013.
 *   http://bit.ly/OpenCV_for_iOS_book
 *****************************************************************************/

#import "ViewController.h"
#import "opencv2/imgcodecs/ios.h"
#include <opencv2/opencv.hpp>
#include <iostream>

using namespace cv;
using namespace std;


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    

    // Alert window
    UIAlertView *alert = [UIAlertView alloc];
    alert = [alert initWithTitle:@"Hey there!"
                         message:@"Welcome to OpenCV on iOS \
                                   development community"
                        delegate:nil
               cancelButtonTitle:@"Continue"
               otherButtonTitles:nil];
    
    [alert show];
    
    char *filename="/Users/Day1/Documents/study/this_term/数字图像处理/数字图像处理图片/lena512.bmp";
    //载入图像
    img=cvLoadImage(filename);
    cv::Mat m = cv::cvarrToMat(img);
    _imageView.image = MatToUIImage(m);
    
    //异常判断
    if(!img){
        cout<<"cannot read image file"<<endl;
        exit(0);
    }
    else{
        cout<<"successfully load the picture"<<endl;
    }
    
    //在载入图片之后，由于openCV中默认图片是BGR格式，因此载入图片的时候会出现失真的情况，因此对应IplImage就应当转换成RGB格式，这样子，老师在书中的代码就可以完全移植到iOS平台上了。
    cvConvertImage(img,img,CV_CVTIMG_SWAP_RB);
    m = cv::cvarrToMat(img);
    _imageView.image =  MatToUIImage(m);

}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)turnGray:(id)sender {
    IplImage *grayresult=cvCreateImage(cvGetSize(img),IPL_DEPTH_8U,1);
    cvCvtColor(img,grayresult,CV_BGR2GRAY);
    cv::Mat m = cv::cvarrToMat(grayresult);
    img = grayresult;
    _imageView.image=MatToUIImage(m);
    img = grayresult;
    
}

- (IBAction)turnGray2:(id)sender {
    
    IplImage *result=cvCreateImage(cvGetSize(img),img->depth,img->nChannels);
    
    CvSize imgtmpsize=cvGetSize(img);
    int nHeight=imgtmpsize.height;
    int nWidth=imgtmpsize.width;
    
    for(int i=0;i<nWidth;i++){
        for(int j=0;j<nHeight;j++){
            CvScalar cvColor=cvGet2D(img, i,j);
            int gray= cvColor.val[0]*0.299+cvColor.val[1]*0.587+cvColor.val[2]*0.114;
            cvColor.val[0]=gray;
            cvColor.val[1]=gray;
            cvColor.val[2]=gray;
            cvSet2D(result, i, j, cvColor);
        }
    }
    cv::Mat m = cv::cvarrToMat(result);
    _imageView.image=MatToUIImage(m);
    img = result;
    
    
}


- (IBAction)turnRedAndBlue:(id)sender {
    
    IplImage *result=cvCreateImage(cvGetSize(img),img->depth,img->nChannels);
    
    CvSize imgtmpsize=cvGetSize(img);
    int nHeight=imgtmpsize.height;
    int nWidth=imgtmpsize.width;
    
    for(int y=0;y<nHeight;y++){
        for(int x=0;x<nWidth;x++){
            CvScalar cvColor=cvGet2D(img, y,x);
            if(y>=30&&y<=60){
                cvColor.val[0]=255;
                cvColor.val[1]=0;
                cvColor.val[2]=0;
            }
            if(x>=50&&x<=90){
                cvColor.val[0]=0;
                cvColor.val[1]=0;
                cvColor.val[2]=255;
            }
            cvSet2D(result, y, x, cvColor);
        }
    }
    cv::Mat m = cv::cvarrToMat(result);
    _imageView.image=MatToUIImage(m);
    img = result;
    
}
- (IBAction)reset:(id)sender {
    char *filename="/Users/Day1/Documents/study/this_term/数字图像处理/数字图像处理图片/lena512.bmp";
    //载入图像
    img=cvLoadImage(filename);
    cv::Mat m = cv::cvarrToMat(img);
    _imageView.image = MatToUIImage(m);
    
    //异常判断
    if(!img){
        cout<<"cannot read image file"<<endl;
        exit(0);
    }
    else{
        cout<<"successfully load the picture"<<endl;
    }
    
    //在载入图片之后，由于openCV中默认图片是BGR格式，因此载入图片的时候会出现失真的情况，因此对应IplImage就应当转换成RGB格式，这样子，老师在书中的代码就可以完全移植到iOS平台上了。
    cvConvertImage(img,img,CV_CVTIMG_SWAP_RB);
    m = cv::cvarrToMat(img);
    _imageView.image =  MatToUIImage(m);
    
}

- (IBAction)binarization:(id)sender {
    
    IplImage* biimg = cvCreateImage(cvGetSize(img),img->depth,img->nChannels);
    CvScalar s;
    int sum=0;
    for (int i=0;i<img->height;i++)
    {
        for (int j=0;j<img->width;j++)
        {
            
            s =  cvGet2D(img,i,j);
            //cout<<s.val[0]<<" "<<s.val[1]<<" "<<s.val[2]<<endl;
            sum = (s.val[0]+s.val[1]+s.val[2])/3;
            if (sum > 128)
            {
                s.val[0]=s.val[1]=s.val[2]=255;
            }
            else
            {
                s.val[0]=s.val[1]=s.val[2]=0;

            }
            cvSet2D(biimg, i, j, s);
        }
    }
    
    cv::Mat m = cv::cvarrToMat(biimg);
    
     _imageView.image=MatToUIImage(m);
    
    img = biimg;

    
    
}
- (IBAction)rotate:(id)sender {
    CvSize imgsize =cvGetSize(img);
    long width=imgsize.width;
    long height=imgsize.height;
    
    
    float x1,y1,x2,y2,x3,y3,x4,y4;
    x1=(float)(-width/2);   y1=(float)(-height/2);
    x2=(float)(-width/2);   y2=(float)(height/2);
    x3=(float)(width/2);   y3=(float)(-height/2);
    x4=(float)(width/2);   y4=(float)(height/2);
    
    //第二步，进行旋转变换；矩阵旋转变换
    double angle=40;
    float RotateAngle=angle *3.1415926535/180.0;
    float sina,cosa;
    sina=(float)sin((double)RotateAngle);
    cosa=(float)cosf((double)RotateAngle);
    //计算旋转后的坐标
    float xn1,yn1,xn2,yn2,xn3,yn3,xn4,yn4;
    xn1=cosa*x1+sina*y1; yn1=cosa*y1-sina*x1;
    xn2=cosa*x2+sina*y2; yn2=cosa*y2-sina*x2;
    xn3=cosa*x3+sina*y3; yn3=cosa*y3-sina*x3;
    xn4=cosa*x4+sina*y4; yn4=cosa*y4-sina*x4;
    
    //第三步，将坐标原点移回左上角
    
    long newWidth,newHeight;
    if(fabs(xn4-xn1)>fabs(xn2-xn3))
        newWidth=fabs(xn4-xn1)+0.5;
    else
        newWidth=fabs(xn2-xn3)+0.5;
    
    if(fabs(yn4-yn1)>fabs(yn2-yn3))
        newHeight=fabs(yn4-yn1)+0.5;
    else
        newHeight=fabs(yn2-yn3)+0.5;
    
    CvSize imgsizeNew;
    imgsizeNew.width=newWidth;
    imgsizeNew.height=newHeight;
    IplImage *resultImg=cvCreateImage(imgsizeNew, img->depth, img->nChannels);
    int i=0;
    for(int x=0;x<newWidth;x++){
        for(int y=0;y<newHeight;y++){
            CvScalar color;
            int x0=(x-newWidth/2)*cosa - (y-newHeight/2)*sina + width/2.0;
            int y0=(x-newWidth/2)*sina + (y-newHeight/2)*cosa + height/2.0;
            if(x0>=0 && x0<width && y0>=0 && y0<height){
                color=cvGet2D(img, x0, y0);
            }
            else{
                color.val[0]=255;
                color.val[1]=255;
                color.val[2]=255;
            }
            cvSet2D(resultImg, x, y, color);
        }
    }
    cv::Mat m = cv::cvarrToMat(resultImg);
    _imageView.image=MatToUIImage(m);
    
    img = resultImg;

    
    
}

//对于放大，但是ios中仍然按照比例放置在image view当中，所以应当解决的问题是要能够动态的变化image view的长宽
- (IBAction)zoom:(id)sender {
    float ratio=2.0;
    CvSize imgsize =cvGetSize(img);
    long width=imgsize.width;
    long height=imgsize.height;
    
    long newWidth=long(width*ratio+0.5);
    long newHeight=long(height*ratio+0.5);
    
    CvSize imgNewSize;
    imgNewSize.width=newWidth;
    imgNewSize.height=newHeight;
    IplImage *resultImg=cvCreateImage(imgNewSize, img->depth, img->nChannels);
    //Step1:先将图像置为白色
    for(int i=0;i<newWidth;i++){
        for(int j=0;j<newHeight;j++){
            CvScalar color;
            color.val[0]=255;
            color.val[1]=255;
            color.val[2]=255;
            cvSet2D(resultImg, i, j, color);
        }
    }
    //Step2:向前映射
    for(int i=0;i<width;i++){
        for(int j=0;j<height;j++){
            CvScalar color=cvGet2D(img, i, j);
            cvSet2D(resultImg, (int)ratio*i, (int)ratio*j, color);
        }
    }
    
    //Step3:使用行插值法/列插值法/周围8个点的平均值
    for(int i=0;i<newWidth;i++){
        for(int j=0;j<newHeight;j++){
            CvScalar color= cvGet2D(resultImg, i, j);
            if(color.val[0]==255&&color.val[1]==255&&color.val[2]==255&&i<=newWidth-2&&i>=1&&j<=newHeight-2&&j>=1)
            {
                
                
                CvScalar colorArr0=cvGet2D(resultImg, i-1, j);
                CvScalar colorArr1=cvGet2D(resultImg, i+1, j);
                CvScalar colorArr2=cvGet2D(resultImg, i-1, j-1);
                CvScalar colorArr3=cvGet2D(resultImg, i+1, j+1);
                CvScalar colorArr4=cvGet2D(resultImg, i-1, j-1);
                CvScalar colorArr5=cvGet2D(resultImg, i+1, j+1);
                CvScalar colorArr6=cvGet2D(resultImg, i-1, j+1);
                CvScalar colorArr7=cvGet2D(resultImg, i+1, j-1);
                int cnt=0;
                if(colorArr0.val[0]!=255&&colorArr0.val[1]!=255&&colorArr0.val[2]!=255){
                    cnt++;
                    color.val[0]+=colorArr0.val[0]; color.val[1]+=colorArr0.val[1]; color.val[2]+=colorArr0.val[2];
                }
                if(colorArr1.val[0]!=255&&colorArr1.val[1]!=255&&colorArr1.val[2]!=255){
                    cnt++;
                    color.val[0]+=colorArr1.val[0]; color.val[1]+=colorArr1.val[1]; color.val[2]+=colorArr1.val[2];
                }
                if(colorArr2.val[0]!=255&&colorArr2.val[1]!=255&&colorArr2.val[2]!=255){
                    cnt++;
                    color.val[0]+=colorArr2.val[0]; color.val[1]+=colorArr2.val[1]; color.val[2]+=colorArr2.val[2];
                }
                if(colorArr3.val[0]!=255&&colorArr3.val[1]!=255&&colorArr3.val[2]!=255){
                    cnt++;
                    color.val[0]+=colorArr3.val[0]; color.val[1]+=colorArr3.val[1]; color.val[2]+=colorArr3.val[2];
                }
                if(colorArr4.val[0]!=255&&colorArr4.val[1]!=255&&colorArr4.val[2]!=255){
                    cnt++;
                    color.val[0]+=colorArr4.val[0]; color.val[1]+=colorArr4.val[1]; color.val[2]+=colorArr4.val[2];
                }
                if(colorArr5.val[0]!=255&&colorArr5.val[1]!=255&&colorArr5.val[2]!=255){
                    cnt++;
                    color.val[0]+=colorArr5.val[0]; color.val[1]+=colorArr5.val[1]; color.val[2]+=colorArr5.val[2];
                }
                if(colorArr6.val[0]!=255&&colorArr6.val[1]!=255&&colorArr6.val[2]!=255){
                    cnt++;
                    color.val[0]+=colorArr6.val[0]; color.val[1]+=colorArr6.val[1]; color.val[2]+=colorArr6.val[2];
                }
                if(colorArr7.val[0]!=255&&colorArr7.val[1]!=255&&colorArr7.val[2]!=255){
                    cnt++;
                    color.val[0]+=colorArr7.val[0]; color.val[1]+=colorArr7.val[1]; color.val[2]+=colorArr7.val[2];
                }
                if(cnt)
                {
                    color.val[0]/=cnt;
                    color.val[1]/=cnt;
                    color.val[2]/=cnt;
                }
                /*
                 color.val[0]=(color1.val[0]+color2.val[0]+color3.val[0]+color4.val[0])/4;
                 color.val[1]=(color1.val[1]+color2.val[1]+color3.val[1]+color4.val[1])/4;
                 color.val[2]=(color1.val[2]+color2.val[2]+color3.val[2]+color4.val[2])/2;*/
                
                cvSet2D(resultImg, i, j, color);
                //cout<<color.val[0]<<" "<<color.val[1]<<" "<<color.val[2]<<endl;
            }
        }
    }
    cv::Mat m = cv::cvarrToMat(resultImg);
    _imageView.image=MatToUIImage(m);
    img = resultImg;

    
    
}
- (IBAction)zoom2:(id)sender {

    IplImage* resultImg;
    
    float XZoomRatio=1.5;
    float YZoomRatio=2.0;
    
    long Width=cvGetSize(img).width;
    long Height=cvGetSize(img).height;
    
    long NewWidth=(long)(Width * XZoomRatio +0.5);
    long NewHeight=(long)(Height * YZoomRatio +0.5);
    CvSize sizeimageNew;
    sizeimageNew.width=NewWidth;
    sizeimageNew.height=NewHeight;
    
    resultImg=cvCreateImage(sizeimageNew, img->depth, img->nChannels);
    for(int x=0;x<NewWidth;x++){
        for(int y=0;y<NewHeight;y++){
            CvScalar color;
            float cx=x/XZoomRatio;
            float cy=y/YZoomRatio;
            if((int(cx)-1)>=0&&(int(cx)+1)<Width&&(int(cy)-1)>=0&&(int(cy)+1)<Height){
                //f(i+u,j+v)=(1-u)(1-v)f(i,j)+(1-u)vf(i,j+1)+u(1-v)f(i+1,j)+uvf
                //(i+1,j+1)
                float u=cx-(int)cx;
                float v=cy-(int)cy;
                int i=(int)cx;
                int j=(int)cy;
                CvScalar color1,color2,color3,color4;
                color1=cvGet2D(img, j, i);
                color2=cvGet2D(img, j+1, i);
                color3=cvGet2D(img, j, i+1);
                color4=cvGet2D(img, j+1, i+1);
                
                int r,g,b;
                g=(1-u)*(1-v)*color1.val[1]+(1-u)*v*color2.val[1]+u*(1-v)*color3.val[1]+u*v*color4.val[1];
                r=(1-u)*(1-v)*color1.val[2]+(1-u)*v*color2.val[2]+u*(1-v)*color3.val[2]+u*v*color4.val[2];
                b=(1-u)*(1-v)*color1.val[0]+(1-u)*v*color2.val[0]+u*(1-v)*color3.val[0]+u*v*color4.val[0];
                
                color.val[0]=b;
                color.val[1]=g;
                color.val[2]=r;
                
            }
            else{
                color.val[0]=255;
                color.val[1]=255;
                color.val[2]=255;
            }
            cvSet2D(resultImg, y, x, color);
        }
        
    }
    cv::Mat m = cv::cvarrToMat(resultImg);
    _imageView.image=MatToUIImage(m);

    img = resultImg;
}




- (IBAction)Van_Gogh:(id)sender {

    // Alert window
    UIAlertView *alert = [UIAlertView alloc];
    alert = [alert initWithTitle:@"Magic here!"
                         message:@"Van Gogh Genetic Algorithm started!"
                        delegate:nil
               cancelButtonTitle:@"Continue"
               otherButtonTitles:nil];
    
    [alert show];
    
    const int specySize=4;
    int totalTime=1000;  //最大换代数
    double crossoverRate=0.99; //交叉率
    double mutationRate=0.001; //变异率
    double selectPossibility[specySize]; //每个个体的选择概率，用于复制的时候
    double Possibility[specySize];  //积累概率
    int crossoverCount[specySize];//计算复制之后每一个原始节点的个数
    const int maxDiffer=20;

    
    
    CvSize imgSize=cvGetSize(img);
    int width=imgSize.width;
    int height=imgSize.height;
    

    IplImage *newImg=cvCreateImage(imgSize, img->depth, img->nChannels);
    
    initialize_img(newImg);
    
    srand((unsigned)time(NULL)); //初始化随机数种子
    for(int i=0;i<width;i++){
        for(int j=0;j<height;j++){
            CvScalar color;
            int r=color.val[0]=rand()%256;
            int g=color.val[1]=rand()%256;
            int b=color.val[2]=rand()%256;
            cvSet2D(newImg, j, i, color);
        }
    }
    
    cv::Mat m = cv::cvarrToMat(newImg);
    _imageView.image=MatToUIImage(m);

    
    //遗传算法开始,规定一个像素点和目标像素点之间r,g，b差值的绝对值和小于20的时候就视为近似相等，标记该像素点成功
    const int totalPixels=width*height;
    bool determinePixel[totalPixels];
    for(int i=0;i<totalPixels;i++)
        determinePixel[i]=false;
    
    double computeRate=f(determinePixel,totalPixels);
    int generation=1;
    
    int cntDifference[totalPixels];
    for(int i=0;i<totalPixels;i++)
        cntDifference[i]=0;
    
    while(generation<=totalTime){
        
        
        //cout<<endl;
        cout<<"generation: "<<generation<<" and the adaptation ratio is: "<<computeRate<<endl;
        
        
        
        
        
        
        //selection
        
        
        for(int i=0;i<width;i++){
            for(int j=0;j<height;j++){
                CvScalar color1=cvGet2D(img, j, i);
                CvScalar color2=cvGet2D(newImg, j, i);
                cntDifference[256*i+j]= abs(color1.val[0]-color2.val[0])+abs(color1.val[1]-color2.val[1])+abs(color1.val[2]-color2.val[2]);
            }
        }
        
        int cnt=0;
        for(int i=0;i<totalPixels;i++){
            if(cntDifference[i]<=maxDiffer){
                cnt++;
                determinePixel[i]=true;
            }
        }
        //cout<<"after selection: "<<cnt<<endl;
        
        
        //crossover 只有不符合条件的会进行交叉，否则就不会进行交叉
        for(int i=0;i<width;i++){
            for(int j=0;j<height;j++){
                CvScalar color1=cvGet2D(img, j, i);
                if(!determinePixel[i*256+j]){
                    if(i!=0&&i!=width-1&&j!=0&&j!=height-1){
                        int x=rand()%3-1;
                        int y=rand()%3-1;
                        
                        CvScalar color2=cvGet2D(newImg, j+y, i+x);
                        CvScalar color3=cvGet2D(newImg, j, i);
                        color3.val[0]=(color3.val[0]+color2.val[0])/2;
                        color3.val[1]=(color3.val[1]+color2.val[1])/2;
                        color3.val[2]=(color3.val[2]+color2.val[2])/2;
                        cvSet2D(newImg, j, i, color3);
                        
                        // change the determinePixel array
                        cntDifference[256*i+j]= cntDifference[256*i+j]+abs(color1.val[0]-color2.val[0])+abs(color1.val[1]-color2.val[1])+abs(color1.val[2]-color2.val[2]);
                        
                        if(cntDifference[256*i+j]<=maxDiffer){
                            determinePixel[256*i+j]=true;
                        }
                        
                        
                    }
                    
                }
            }
        }
        
        int cnt1=0;
        for(int i=0;i<totalPixels;i++){
            if(cntDifference[i]<=maxDiffer){
                cnt1++;
                determinePixel[i]=true;
            }
        }
        //cout<<"after crossover: "<<cnt1<<endl;
        
        
        //mutation
        for(int i=0;i<width;i++){
            for(int j=0;j<height;j++){
                if(!determinePixel[256*i+j]){
                    double p=rand()%10000/10001.0;
                    CvScalar color1=cvGet2D(img, j, i);
                    if(p<mutationRate){
                        int r=rand()%256;
                        int g=rand()%256;
                        int b=rand()%256;
                        CvScalar color2;
                        color2.val[0]=r;
                        color2.val[1]=g;
                        color2.val[2]=b;
                        cvSet2D(newImg, j, i, color2);
                        // change the determinePixel array
                        cntDifference[256*i+j]= cntDifference[256*i+j]+abs(color1.val[0]-color2.val[0])+abs(color1.val[1]-color2.val[1])+abs(color1.val[2]-color2.val[2]);
                        if(cntDifference[256*i+j]<=maxDiffer){
                            determinePixel[256*i+j]=true;
                        }
                    }
                }
            }
        }
        
        int cnt2=0;
        for(int i=0;i<totalPixels;i++){
            if(cntDifference[i]<=maxDiffer){
                cnt2++;
                determinePixel[i]=true;
            }
        }
        
        
        //希望能够实现同步展示图片的变化，但是没有做到
        cv::Mat m = cv::cvarrToMat(newImg);
        _imageView.image=MatToUIImage(m);

        
        
        generation++;
        computeRate=f(determinePixel,totalPixels);

        
        
    }


    
    
    
}

double f(bool determinPixel[],int size){
    int total=0;
    
    for(int i=0;i<size;i++){
        if(determinPixel[i])
            total++;
    }
    
    return total/double(size);
}



void initialize_img(IplImage *img){
    CvSize size=cvGetSize(img);
    int width=size.width;
    int height=size.height;
    for(int i=0;i<width;i++){
        for(int j=0;j<height;j++){
            CvScalar color;
            color.val[0]=255; color.val[1]=255; color.val[2]=255;
            cvSet2D(img, j, i, color);
        }
    }
}

- (IBAction)OnhierarchyColor:(id)sender {
    //Set the hierarchices
    int level = 6;
    CvScalar *colors = new CvScalar[level]; //使用指针实现数组的动态分配
    srand((unsigned int)time(NULL));
    for(int i=0;i<level;i++){
        colors[i].val[0] = (unsigned char)rand()%255;
        colors[i].val[1] = (unsigned char)rand()%255;
        colors[i].val[2] = (unsigned char)rand()%255;
    }
    
    IplImage *result=cvCreateImage(cvGetSize(img),img->depth,img->nChannels);
    CvSize imgtmpsize=cvGetSize(img);
    int nHeight=imgtmpsize.height;
    int nWidth=imgtmpsize.width;
    
    for(int i=0;i<nHeight;i++){
        for(int j=0;j<nWidth;j++){
            CvScalar color;
            color = cvGet2D(img, i, j);
            int this_level = color.val[0]/50;
            cvSet2D(result, i, j, colors[this_level]);
        }
    }
    
    cv::Mat m = cv::cvarrToMat(result);
    _imageView.image=MatToUIImage(m);
    img = result;
}

- (IBAction)onMean:(id)sender {
    cout<<"均值滤波"<<endl;
    cvSmooth(img, img,CV_BLUR,3,3,0,0);
}

- (IBAction)pepper:(id)sender {
    cout<<"中值滤波"<<endl;
    cvSmooth(img, img,CV_MEDIAN,3,3,0,0);
}

- (IBAction)onGradSharp:(id)sender {
    cout<<"梯度锐化方法"<<endl;
    //梯度锐化方法
    IplImage *result=cvCreateImage(cvGetSize(img),img->depth,img->nChannels);
    CvSize imgtmpsize=cvGetSize(img);
    int nHeight=imgtmpsize.height;
    int nWidth=imgtmpsize.width;
    for(int i=0;i<nHeight-1;i++){
        for(int j=0;j<nWidth-1;j++){
            CvScalar color1 = cvGet2D(img, i, j);
            CvScalar color2 = cvGet2D(img, i+1, j);
            CvScalar color3 = cvGet2D(img, i, j+1);
            int bTemp = abs(color1.val[0]-color2.val[0])+abs(color1.val[0]-color3.val[0]);
            //判断是否超过了像素点的能表示的范围
            if(bTemp<255){
                //梯度值小，说明是背景，背景置为白色
                if(bTemp<20){
                    color1.val[0]=255;
                    color1.val[1]=255;
                    color1.val[2]=255;
                    cvSet2D(result, i, j, color1);
                }
                //梯度大说明是边缘，边缘置为梯度值
                else{
                    color1.val[0] = bTemp;
                    color1.val[1] = bTemp;
                    color1.val[2] = bTemp;
                    
                    cvSet2D(result, i, j, color1);
                }
            }
            else{
                color1.val[0] = 255;
                cvSet2D(result, i, j, color1);
            }
        }
    }
    cv::Mat m = cv::cvarrToMat(result);
    _imageView.image=MatToUIImage(m);
    img = result;
}

- (IBAction)OnLaplacian:(id)sender {
    IplImage *result=cvCreateImage(cvGetSize(img),img->depth,img->nChannels);
    cvLaplace(img, result,7);
    cv::Mat m = cv::cvarrToMat(result);
    _imageView.image=MatToUIImage(m);
    img = result;
    


}

- (IBAction)OnDFT:(id)sender {
    
    /*cv::Mat m = cv::cvarrToMat(img);
    _imageView.image=MatToUIImage(m);

    cv::Mat I = cv::cvarrToMat(img);*/
    
    /*if( I.empty()){
        cout<<"empty"<<endl;
    }
    
    
    
    Mat padded;                            //expand input image to optimal size
    int m = getOptimalDFTSize( I.rows );
    int n = getOptimalDFTSize( I.cols ); // on the border add zero values
    copyMakeBorder(I, padded, 0, m - I.rows, 0, n - I.cols, BORDER_CONSTANT, Scalar::all(0));
    
    Mat planes[] = {Mat_<float>(padded), Mat::zeros(padded.size(), CV_32F)};
    Mat complexI;
    merge(planes, 2, complexI);         // Add to the expanded another plane with zeros
    
    dft(complexI, complexI);            // this way the result may fit in the source matrix
    
    // compute the magnitude and switch to logarithmic scale
    // => log(1 + sqrt(Re(DFT(I))^2 + Im(DFT(I))^2))
    split(complexI, planes);                   // planes[0] = Re(DFT(I), planes[1] = Im(DFT(I))
    magnitude(planes[0], planes[1], planes[0]);// planes[0] = magnitude
    Mat magI = planes[0];
    
    magI += Scalar::all(1);                    // switch to logarithmic scale
    log(magI, magI);
    
    // crop the spectrum, if it has an odd number of rows or columns
    magI = magI(cv::Rect(0, 0, magI.cols & -2, magI.rows & -2));
    
    // rearrange the quadrants of Fourier image  so that the origin is at the image center
    int cx = magI.cols/2;
    int cy = magI.rows/2;
    
    Mat q0(magI, cv::Rect(0, 0, cx, cy));   // Top-Left - Create a ROI per quadrant
    Mat q1(magI, cv::Rect(cx, 0, cx, cy));  // Top-Right
    Mat q2(magI, cv::Rect(0, cy, cx, cy));  // Bottom-Left
    Mat q3(magI, cv::Rect(cx, cy, cx, cy)); // Bottom-Right
    
    Mat tmp;                           // swap quadrants (Top-Left with Bottom-Right)
    q0.copyTo(tmp);
    q3.copyTo(q0);
    tmp.copyTo(q3);
    
    q1.copyTo(tmp);                    // swap quadrant (Top-Right with Bottom-Left)
    q2.copyTo(q1);
    tmp.copyTo(q2);
    
    normalize(magI, magI, 0, 1, CV_MINMAX); // Transform the matrix with float values into a
    // viewable image form (float between values 0 and 1).
    
    
    imshow("Input Image"       , I   );    // Show the result
    imshow("spectrum magnitude", magI);*/
    //_imageView.image=MatToUIImage(I);
    

}

- (IBAction)onDFTTest:(id)sender {
    const char* filename = "/Users/Day1/Documents/study/this_term/数字图像处理/数字图像处理图片/lena512.bmp";
    
    Mat I = imread(filename, CV_LOAD_IMAGE_GRAYSCALE);
    
     if( I.empty()){
     cout<<"empty"<<endl;
     }
     
     
     
     Mat padded;                            //expand input image to optimal size
     int m = getOptimalDFTSize( I.rows );
     int n = getOptimalDFTSize( I.cols ); // on the border add zero values
     copyMakeBorder(I, padded, 0, m - I.rows, 0, n - I.cols, BORDER_CONSTANT, Scalar::all(0));
     
     Mat planes[] = {Mat_<float>(padded), Mat::zeros(padded.size(), CV_32F)};
     Mat complexI;
     merge(planes, 2, complexI);         // Add to the expanded another plane with zeros
     
     dft(complexI, complexI);            // this way the result may fit in the source matrix
     
     // compute the magnitude and switch to logarithmic scale
     // => log(1 + sqrt(Re(DFT(I))^2 + Im(DFT(I))^2))
     split(complexI, planes);                   // planes[0] = Re(DFT(I), planes[1] = Im(DFT(I))
     magnitude(planes[0], planes[1], planes[0]);// planes[0] = magnitude
     Mat magI = planes[0];
     
     magI += Scalar::all(1);                    // switch to logarithmic scale
     log(magI, magI);
     
     // crop the spectrum, if it has an odd number of rows or columns
     magI = magI(cv::Rect(0, 0, magI.cols & -2, magI.rows & -2));
     
     // rearrange the quadrants of Fourier image  so that the origin is at the image center
     int cx = magI.cols/2;
     int cy = magI.rows/2;
     
     Mat q0(magI, cv::Rect(0, 0, cx, cy));   // Top-Left - Create a ROI per quadrant
     Mat q1(magI, cv::Rect(cx, 0, cx, cy));  // Top-Right
     Mat q2(magI, cv::Rect(0, cy, cx, cy));  // Bottom-Left
     Mat q3(magI, cv::Rect(cx, cy, cx, cy)); // Bottom-Right
     
     Mat tmp;                           // swap quadrants (Top-Left with Bottom-Right)
     q0.copyTo(tmp);
     q3.copyTo(q0);
     tmp.copyTo(q3);
     
     q1.copyTo(tmp);                    // swap quadrant (Top-Right with Bottom-Left)
     q2.copyTo(q1);
     tmp.copyTo(q2);
     
     normalize(magI, magI, 0, 1, CV_MINMAX); // Transform the matrix with float values into a
     // viewable image form (float between values 0 and 1).
     
     
     //imshow("Input Image"       , I   );    // Show the result
     //imshow("spectrum magnitude", magI);
    _imageView.image=MatToUIImage(magI);
    

    
}

//均值滤波.实现成功
- (IBAction)onReal:(id)sender {
    Mat I = cv::cvarrToMat(img);
    blur(I, I, cv::Size(7, 7),cv::Point(-1, -1), cv::BORDER_DEFAULT);
    _imageView.image=MatToUIImage(I);
    
    
    
}

//高斯滤波器
- (IBAction)GaussianBlur:(id)sender {
    Mat I = cv::cvarrToMat(img);
    GaussianBlur(I, I, cv::Size(7, 7), 1.5);
    _imageView.image=MatToUIImage(I);

}

- (IBAction)HighPassFilter:(id)sender {
    cout<<"This is high pass filter"<<endl;
}

- (IBAction)selectPhoto:(id)sender {
    
    
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    
    [self presentViewController:picker animated:YES completion:NULL];
}

#pragma mark - Image Picker Controller delegate methods


- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    UIImage *chosenImage = info[UIImagePickerControllerEditedImage];
    _imageView.image = chosenImage;
    Mat m;
    UIImageToMat(chosenImage, m);
    
    
    Mat mat1; // mat1是临时变量
    mat1=m.clone();// 包括数据的深度复制，以防对mat数据的更改
    img=cvCreateImage(cvSize(m.cols,m.rows),8,3); //根据实际进行初始化
    img->imageData=(char*)mat1.data;

    CvSize size=cvGetSize(img);
    cout<<"图片大小： "<<size.width<<" "<<size.height<<endl;


    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}



@end
